
package Main;

public class FigBrasao extends Figurinha{    
    
    private String raridade;    
    private String selecaoBrasao;

    public FigBrasao() {
    }

    public FigBrasao(String raridade,String selecaoBrasao) {
        this.raridade = raridade;
        this.selecaoBrasao = selecaoBrasao;
    }

    @Override
    public String toString() {
        return "FigBrasao{" + "raridade=" + raridade + ", selecaoBrasao=" + selecaoBrasao + '}';
    }

    public String getRaridade() {
        return raridade;
    }

    public void setRaridade(String raridade) {
        this.raridade = raridade;
    }

    public String getSelecaoBrasao() {
        return selecaoBrasao;
    }

    public void setSelecaoBrasao(String selecaoBrasao) {
        this.selecaoBrasao = selecaoBrasao;
    }
    
}
