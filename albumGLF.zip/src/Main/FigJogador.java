
package Main;

public class FigJogador extends Figurinha{    
    
    private String nomeJogador;
    private int numCamisa;
    private int idadeJogador;
    private String timeJogador;       
    private String selecaoJogador;
    private String nacionalidadeJogador;
    private Boolean titular;

    public FigJogador() {
    }

    public FigJogador(String nomeJogador, int numCamisa, int idadeJogador, String timeJogador, String selecaoJogador, String nacionalidadeJogador, Boolean titular) {
        this.nomeJogador = nomeJogador;
        this.numCamisa = numCamisa;
        this.idadeJogador = idadeJogador;
        this.timeJogador = timeJogador;
        this.selecaoJogador = selecaoJogador;
        this.nacionalidadeJogador = nacionalidadeJogador;
        this.titular = titular;
    }

    @Override
    public String toString() {
        return "FigJogador{" + "nomeJogador=" + nomeJogador + ", numCamisa=" + numCamisa + ", idadeJogador=" + idadeJogador + ", timeJogador=" + timeJogador + ", selecaoJogador=" + selecaoJogador + ", nacionalidadeJogador=" + nacionalidadeJogador + ", titular=" + titular + '}';
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public int getNumCamisa() {
        return numCamisa;
    }

    public void setNumCamisa(int numCamisa) {
        this.numCamisa = numCamisa;
    }

    public int getIdadeJogador() {
        return idadeJogador;
    }

    public void setIdadeJogador(int idadeJogador) {
        this.idadeJogador = idadeJogador;
    }

    public String getTimeJogador() {
        return timeJogador;
    }

    public void setTimeJogador(String timeJogador) {
        this.timeJogador = timeJogador;
    }

    public String getSelecaoJogador() {
        return selecaoJogador;
    }

    public void setSelecaoJogador(String selecaoJogador) {
        this.selecaoJogador = selecaoJogador;
    }

    public String getNacionalidadeJogador() {
        return nacionalidadeJogador;
    }

    public void setNacionalidadeJogador(String nacionalidadeJogador) {
        this.nacionalidadeJogador = nacionalidadeJogador;
    }

    public Boolean getTitular() {
        return titular;
    }

    public void setTitular(Boolean titular) {
        this.titular = titular;
    }
    
}
